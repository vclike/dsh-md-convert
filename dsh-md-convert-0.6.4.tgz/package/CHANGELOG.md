# Changelog

本项目所有显著变更记录于此。格式参考 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/),
版本遵循 [语义化版本](https://semver.org/lang/zh-CN/)。

## [0.6.4] - 2026-10-06

双链路对照实测驱动的第二批:文字层**标题层级重建**与**页级局部 vision 路由骨架**——
图像密集页不再只能整册视觉重转,只对命中页出子集任务书,按锚点块合并回文字层版。
97 项测试全绿(+9),extract_text 活体自验转正(`npm run test:py`)。

### Added(新增)

- **标题层级重建**(`extract_text.py --no-headings` 关闭):行框高度聚类正文字号,
  ≥1.25× 为标题候选、≥1.40× → `##` 其余 `###`;紧邻续行合并(中文标题+西文 run
  拆行、包围盒强重叠形态,如「使用」+「Evolve Skill」)。真机校准:正文 h≈9.5,
  节标题≈1.45×,章标题≈2.48×;曾出现候选阈值差 0.01 漏字(`进化` 12.34 vs 12.35),
  校准后 14 个标题全数命中。
- **逐页图像占比 → visionHints**:raw 页面对象枚举(零渲染)统计 `FPDF_PAGEOBJ_IMAGE`
  面积占**页面面积**比(v0.6.4 两次真机修正:分母由对象面积总和改为页面面积;
  常量改用官方 `FPDF_PAGEOBJ_IMAGE`=3——硬编码 1 曾把 TEXT 对象当图像)。
  ≥15% 的页随结果返回 `visionHints:{threshold,pages,detail}`,真机校准:截图页 0.224,
  纯文字页 ≈0。
- **onlyPages 子集任务书**:`md_convert({engine:"vision", onlyPages:"5,7-9"})` 只渲染/
  转写命中页;`render_pages.py --pages` 子集渲染(manifest 新增 `pageList` 与 files
  按序对应);`computeBatchesForPages` 子集切批;`plan.source.pageList/subset` 落盘,
  子集产物 `<名>-p5-p7.md` 不覆盖全页版,`plan.assemble.merge` 附锚点替换合并指引。
- **assemble 子集感知**:`plan.source.pageList` 存在时覆盖率与合并只考察子集,
  其余页由文字层版承担;尾注标 `页子集`。
- **文字层活体自验转正**(`lib/py/selftest_extract.py` + `npm run test:py`):
  `MDC_TEST_PDF` 指向文字层 PDF 即启用(协议字段/确定性/开关生效/页眉脚剥离/
  单级 # 不新增——bash 注释行与误标不可分,改为对照断言),无环境优雅 SKIP。

### Fixed(修复)

- `FPDF_PAGEOBJ_IMAGE` 硬编码 1(实为 3,1 是 TEXT):首版 img_ratio 把文本对象
  面积当图像,分母错误与常量错误两处真机实测先后暴露并修正。

## [0.6.3] - 2026-10-05

双链路对照实测(火山方舟 PDF:文字层版 vs 视觉版逐页 diff)驱动的一轮文字层
质量升级:链接零丢失、页眉页脚剥离、孤儿符号回挂,并修复 `engine="vision"`
被静默吞掉的缺陷。文字层兜底 88 项测试全绿。

### Added(新增)

- **链接提取**(`extract_text.py --links`,默认开):raw `FPDFLink_Enumerate` +
  `FPDFAction_GetURIPath` 提取 URI 链接;URL 尾段文件名能在正文回查时内联为
  `[文件名](url)`(如 `evolve-setup-claude_code.zip`),其余入页尾「本页链接:」
  脚注——URL 零丢失。实证决策:`FPDFLink_CountRects/GetRect` 在 pypdfium2 raw
  绑定下对部分链接注解触发 access violation,逐链接矩形锚文本路放弃,
  用零风险文本启发式替代。
- **页眉页脚剥离**(`--no-headers` 关闭,默认开):边距带(y 比例) + 跨页重复
  (≥max(2,60% 页数)) + 版权/页码正则,三条件剥除运行时页眉/版权行/页码
  (实测:9 页文档剥离 55 行)。
- **孤儿符号回挂**:与正文断行的列表符/序号回挂为 `- 正文` / `N. 正文`;
  连续符号行(页边距栏布局幽灵)识别并丢弃,不再互挂成 `1. 2.`
  (实测:回挂 4 处,丢弃幽灵 31 处)。
- **提取统计随 `notes` 返回**:links_inlined/links_footnote/stripped_lines/
  orphan_merged/orphan_dropped,质量可观测。
- **vision 路由回归测试**(`test/vision-route.test.js`):显式 `engine="vision"`
  必达任务书 + 渲染失败显式返回 `E_VISION_PLAN`,均注入假渲染不触 Python。

### Fixed(修复)

- **`engine="vision"` 被静默吞掉**:`convertFile` modern-PDF 分支此前无条件先试
  文字层,有文字层的 PDF 上 vision 路由永不可达(`E_VISION_PLAN` 死码)。
  现显式 `engine="vision"` 直达扫描件路由;显式指定时 vision 失败原样报错,
  不静默降级为文字层。
- **成功路径 warnings 不渲染**:`renderOutput` 此前成功时丢弃 `warnings`
  (markitdown 兜底原因只能翻输出文件 footer 获知),现三种成功形态均透出。

[0.6.4]: https://github.com/yakoylp/dsh-md-convert/compare/v0.6.3...v0.6.4

[0.6.3]: https://github.com/yakoylp/dsh-md-convert/compare/v0.6.2...v0.6.3

## [0.6.2] - 2026-10-05

修复文字层 PDF 在宿主内被误判为扫描件的问题(火山方舟 PDF 实测:markitdown 在
Electron 宿主运行时内返回空,被 `catch { md = "" }` 静默吞掉,误走慢速 OCR),
并把引擎选择固化为一套可解释的路由决策逻辑。

### Added(新增)

- **文字层双引擎**(`convertPdfTextLayer`):markitdown 失败/为空时,用本来就依赖的
  pypdfium2(`lib/py/extract_text.py`,零新增依赖)兜底直提文字层——秒级、页锚点保序;
  每层尝试结果记入 `attempts`,失败原因随 `warnings` 透出,不再静默吞错。
- **引擎路由决策表**(README):有文字层→markitdown(宿主内失败→pypdfium2 兜底);
  无文字层→按复杂度分流(≤40% 本地 OCR,>40% vision 模型阅读);长任务后台优先、
  前台 30 页闸门。文字层链路返回 `decision:{route:"text-layer",via}`。

### Fixed(修复)

- `convertFile` 文字层 `catch { md = "" }` 静默吞错 → 失败原因进 `warnings`
  (如 `markitdown 文字层提取失败(<原因>),已用 pypdfium2 兜底直提`)。
- 工具失败渲染补显 `warnings`(此前后台降级/闸门拦截的具体原因对调用方不可见)。

[0.6.2]: https://github.com/yakoylp/dsh-md-convert/compare/v0.6.1...v0.6.2

## [0.6.1] - 2026-10-05

修复 97 页纯扫描采购文件实战暴露的三类缺陷:**后台作业启动失败打穿工具调用**、
**workers 默认无内存预算拖垮整机**、**前台长任务无闸门**。全部修复带回归单测
(81 项全绿,含 spawnStream 部署级真跑)。

### Fixed(修复)

- **后台作业启动降级链**(`startBackgroundConvert`):宿主拒绝 `owner: exec.agent`
  (实测报错 `session "[object Object]" has no live agent (background job owner must be live)`;
  传法与官方插件文档一致,疑似宿主侧契约漂移/回归,待上游取证)时,原实现裸调用
  `jobs.start` 使整个 `md_convert` 调用失败。现逐级降级:带 owner → 无 owner
  (unowned bucket,附 warning 提示轮询 `job_output`)→ 前台执行,任何一级失败都
  不再使调用报错(对齐 dsh-tabbit installer 同位保护)。
- **资源感知默认 workers**(`defaultWorkers`):旧默认 `min(CPU,8)` 在 22 核机即
  8 路并行 PaddleOCR,内存饱和致整机卡顿、单页 33s(bench 单 worker 基准 14.4s)。
  新默认 `min(CPU, 4, 内存预算/2.5GB)`(bench 只标定到 4 workers);Node 侧为
  单一事实源,`workers<=0` 由 `createOcrRun` 解析后显式下传 Python;
  `parallel_ocr.py` 独立 CLI 默认同步对齐(Win32 ctypes / POSIX sysconf)。
  ETA 估算(F5)同步换口径。
- **前台 OCR 页数闸门**(`ocr.foregroundMaxPages`,默认 30,0=不限制):
  `background=false` 前台跑大扫描件会占满 CPU/内存(2026-10-05 事故:97 页前台
  10 分钟仅完成 18 页且拖垮整机)。超限返回 `E_FOREGROUND_LIMIT`(新增稳定错误码)
  并附替代路线(后台 / vision / resume / 解除配置)与本地 ETA 提示;页数探查失败
  (<1s)不设闸不承诺 ETA;vision 任务书链路不受闸。
- **测试保真度 F8-2**(`spawnStream` 直测):断言了句柄上不存在的 `.killed` 属性
  (照测试替身形状写,开发沙箱 EPERM skip 从未真跑);部署级环境首次真跑即失败。
  修正为断言结案结果对象上的 `killed`。

### Changed(变更)

- 工具描述与三语 README 同步:降级链语义、新配置 `ocr.foregroundMaxPages`、
  workers 资源感知默认;CLI `--workers` 帮助文本对齐。
- 单测 81 项(v0.6.0 为 72 项):新增降级链/前台闸门/资源感知 workers 用例;
  spawnStream 直测在宿主级环境真实执行并通过。

[0.6.1]: https://github.com/yakoylp/dsh-md-convert/compare/v0.6.0...v0.6.1

## [0.6.0] - 2026-09-24

解决「长文档纯图 PDF 同步单调用被宿主中断」的结构性缺陷:转换链路升级为
**三层引擎路由 + 后台作业化 + 断点续跑 + vision 任务书闭环**。

### Added(新增)

- **三层引擎路由**(扫描件 PDF):文字层直提(markitdown)→ 复杂度探针抽样 3 页
  (首页 + 1/3 + 2/3,仅版面模型)→ 表格/公式区域占比超过 `vision.complexityRatio`
  (默认 0.4)走 vision 任务书,否则页级并行本地 OCR(任意页数);
  `vision.pagesThreshold`(默认 0=不限)保留为可选强制换轨闸;
  `engine=local|vision` 可跳过探针强制指定;探针失败保守回退本地;复杂度接近阈值时
  返回 hint 建议对比 vision 质量。
- **页级并行 OCR**(`lib/py/parallel_ocr.py`):multiprocessing.Pool 页级并行
  (initializer 一次加载引擎)+ NDJSON 流式输出(start/page/done 逐行 flush)+
  `<!--PAGE:NN-->` 页锚点 + `--resume` 断点续跑(state.json 原子落盘:跳过 done/
  重试 failed/坏状态防护)+ 失败页降级不中断 + `--probe` 复杂度探针 +
  `--workers 1` 进程内快速路径(免管道,兼容沙箱/容器)。
- **后台作业化**(`md_convert` 工具):OCR 类长任务经 `ctx.jobs` 后台执行,
  立即返回 `{ok, background:true, jobId, etaSec}`;`background=auto|true|false`、
  `engine`、`resume` 参数;**缺后台控制器时优雅降级前台并附 warning,不失败**;
  `job_kill` 取消(进程树终止,已完成页保留可续跑);done 结算为官方
  `JobOutcome{status,detail,output}` 契约。
- **vision 任务书生成**(`lib/core/vision.js`):render_pages.py 渲染 PNG →
  连续切批(`vision.batchSize` 默认 8)→ 高保真 OCR 提示词模板实例化
  (内置 `lib/py/prompts/vision-ocr.md`,`vision.promptTemplate` 可整体覆盖)→
  `plan.json` 任务书(批次/页归属/图像清单/输出契约/装配入口)。
- **装配与完整性校验工具 `md_convert_assemble`**:消费 plan.json 对各批 output 做
  确定性校验(存在非空/锚点覆盖 1..N 无缺无重无越批/严格 UTF-8/GBK 双重编码
  乱码特征/极短页统计)→ 按 PAGE 序合并最终 md;有问题仍装配(缺页占位)并返回
  findings;`review:true` 生成复查任务书(原 PNG + 逐字校正提示词 + 整批重写契约)
  并更新 plan.json,复查后重跑即再校验。CLI:`dsh-md-convert assemble <plan.json> [--review]`。
- **配置全面参数化**(Schemastery,零硬编码):`background`/`engine`/
  `ocr.workers|probeTimeoutMs|runTimeoutMs|etaPerPageSec`/
  `vision.pagesThreshold|complexityRatio|batchSize|renderScale|promptTemplate`。
- **新增稳定错误码**:`E_OCR_TIMEOUT`(前台 OCR/探针超时,可 resume)、
  `E_VISION_PLAN`(vision 任务书链路失败)、`E_ASSEMBLE`(装配致命失败)。
- 3 页纯图测试 fixture(文字层 0 字符)+ 97 页装配冒烟生成器
  (`--remove-page N` 演练缺页);单测六套 72 项全绿。

### Changed(变更)

- 扫描件 OCR 从「整份 PDF 一次同步调用」改为页级并行流式消费;
  收尾增加 state↔md 对账(防 job_kill/超时窗口静默丢页,差异页写入 warnings +
  progress 标注)与原子写盘。
- ETA 估算按实际 worker 口径(workers=0 → min(CPU,8))+ 多 worker 固定开销 40s
  (bench.md 标定:97 页 workers=4 ≈ 404s,落在 400-420s 实测区间)。
- CLI 新增 `convert` 子命令与 `--engine/--background/--resume/--review/--workers` 旗标。

### Known Issues(已知问题)

- **多 worker Pool 并行与 ctx.jobs 后台链路待部署阶段实测**:开发会话沙箱禁命名管道,
  `--workers 2+`(multiprocessing.Pool)与 node→python 管道 spawn 在沙箱内 EPERM
  (pipe=EPERM/inherit=OK 已定界,非代码缺陷)。部署验证命令:
  `dsh-md-convert convert 采购文件.pdf -o ./md --background true --workers 2`
  (97 页预期 6-7 分钟,ETA 标定 400-420s);`npm test` 中 spawnStream 直测
  在受限环境自动跳过、部署机自动真跑。
- OCR 质量取决于版面清晰度;复杂表格(多层合并/斜线表头)、超小字号可能识别不全
  (复杂版面建议 `engine:"vision"`)。
- vision 链路产出的复查任务书依赖 agent 编排转写(工具自身不调在线视觉 API)。

[0.6.0]: https://github.com/yakoylp/dsh-md-convert/compare/v0.5.6...v0.6.0
