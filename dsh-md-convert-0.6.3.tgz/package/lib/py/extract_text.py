# -*- coding: utf-8 -*-
"""
dsh-md-convert — PDF 文字层直提兜底(pypdfium2,v0.6.3 结构增强)

用途: markitdown-node 在宿主运行时(Electron 内置 Node)内对部分文字层 PDF
失败/返回空时的秒级兜底——纯文字提取 + 三个确定性结构增强(零 OCR 零新增依赖):

  1. 链接提取(P0-2): raw FPDFLink_Enumerate/FPDFAction_GetURIPath 提取 URI 链接,
     单矩形锚文本回填为 [文本](url);多矩形/空锚降级为页尾脚注,不丢 URL。
  2. 页眉页脚剥离(P0-3): 边距带(y 比例) + 跨页重复(≥60% 且 ≥2 页) + 页脚正则,
     剥除运行时页眉/版权行/页码。
  3. 孤儿符号回挂(P0-4): 与正文断行的列表符(•)/序号(1.)回挂到下一条内容行。

行为开关(默认全开,供 A/B 与安全回退):
  --no-links / --no-headers / --margin <ratio>
保底路径: 行框/链接任一 API 异常时逐级降级到旧版 get_text_bounded 全文直提,绝不失败。

stdout 协议(单个 JSON,UTF-8):
  {"total": 9, "pages": [{"no": 1, "text": "..."}, ...], "notes": {...}}
  打不开 PDF: {"ok": false, "error": "..."} 并退出码 1
"""
import argparse
import ctypes
import json
import re
import sys
from collections import Counter

import pypdfium2 as pdfium

try:
    import pypdfium2.raw as pdfium_c
except Exception:  # pragma: no cover - raw 模块缺失时仅链接功能降级
    pdfium_c = None

# 页眉/页脚边距带(占页高比例;pdfium 原点左下,y 向上)
MARGIN_RATIO = 0.12
# 同带内重复行判定的页数阈值:max(2, ceil(0.6 * 有效页数))
REPEAT_RATIO = 0.6
# 页眉/页脚区正则(仅边距带内生效,避免误杀正文)
ZONE_LINE_PAT = re.compile(
    r"^(?:版权所有©?.*|\d+(?:\s*/\s*\d+)?|第\s*\d+\s*页(?:.*共\s*\d+\s*页)?|Powered by .+)$"
)
# 孤儿列表符(仅符号、无正文)
BULLET_ONLY_PAT = re.compile(r"^[•·◦‣▪○●□■◆◇*+\-–—]+$")
# 孤儿序号(阿拉伯/括号序号,后随断行)
NUM_ONLY_PAT = re.compile(r"^(\d{1,2}[.、]|\(\d{1,2}\)[.、]?|\[\d{1,2}\][.、]?)$")
URI_ACTION_TYPE = 3  # pdfium action type: URI


def _utf8_stdio():
    """Windows 管道默认 GBK,JSON 输出强制 UTF-8。"""
    for s in (sys.stdout, sys.stderr):
        try:
            s.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


def _norm(text):
    """归一化用于跨页重复比较(去全部空白差异)。"""
    return re.sub(r"\s+", "", text or "")


def _page_lines(tp):
    """行框提取: [(y_bottom, y_top, text)] 按字符序(阅读序);异常返回 None。"""
    try:
        n = tp.count_rects()
        lines = []
        for i in range(n):
            l, b, r, t = tp.get_rect(i)
            txt = tp.get_text_bounded(left=l, bottom=b, right=r, top=t)
            txt = (txt or "").strip()
            if txt:
                lines.append((float(b), float(t), txt))
        return lines or None
    except Exception:
        return None


def _page_links(doc_raw, page_raw):
    """URI 链接提取: [(anchor_text, url)];raw API 异常返回 None(调用方降级)。

    v0.6.3 决策: FPDFLink_CountRects/GetRect 在 pypdfium2 raw 绑定下对部分链接
    注解触发 access violation(真机实证),逐链接矩形锚文本路放弃;
    anchor 恒为空串,由 _apply_links 用「URL 尾段文件名回查正文」启发式内联。
    """
    if pdfium_c is None:
        return None
    out = []
    try:
        link_holder_t = pdfium_c.FPDFLink_Enumerate.argtypes[2]._type_
        link_holder = link_holder_t()
        start = ctypes.c_int(0)
        for _ in range(128):  # 单页链接数保险丝
            if not pdfium_c.FPDFLink_Enumerate(page_raw, ctypes.byref(start), ctypes.byref(link_holder)):
                break
            action = pdfium_c.FPDFLink_GetAction(link_holder)
            if not action:
                continue
            if pdfium_c.FPDFAction_GetType(action) != URI_ACTION_TYPE:
                continue
            need = pdfium_c.FPDFAction_GetURIPath(doc_raw, action, None, 0)
            if need <= 0:
                continue
            buf = ctypes.create_string_buffer(need)
            pdfium_c.FPDFAction_GetURIPath(doc_raw, action, buf, need)
            url = buf.raw.decode("utf-8", errors="replace").rstrip("\x00")
            if not url:
                continue
            out.append(("", url))
        return out
    except Exception:
        return None


def _detect_headers_footers(pages_meta, margin):
    """跨页页眉/页脚判定: 边距带内 跨页重复(≥max(2,60%页数)) 或 命中页码/版权正则。

    pages_meta: [{"no", "lines", "page_h"}];返回 set[归一化文本]。
    """
    strip = set()
    usable = [m for m in pages_meta if m["lines"] and m["page_h"] > 0]
    if not usable:
        return strip
    n_pages = len(usable)
    threshold = max(2, -(-n_pages * REPEAT_RATIO // 1))  # ceil(0.6N) 且 ≥2
    by_zone = {"top": Counter(), "bottom": Counter()}
    for m in usable:
        h = m["page_h"]
        for b, t, txt in m["lines"]:
            if t >= h * (1 - margin):
                by_zone["top"][_norm(txt)] += 1
            elif b <= h * margin:
                by_zone["bottom"][_norm(txt)] += 1
    for zone in by_zone:
        for key, cnt in by_zone[zone].items():
            if cnt >= threshold:
                strip.add(key)
    # 正则候选(边距带内出现≥1 次即剥:版权行/页码/第N页)
    for m in usable:
        h = m["page_h"]
        for b, t, txt in m["lines"]:
            if (t >= h * (1 - margin) or b <= h * margin) and ZONE_LINE_PAT.match(txt):
                strip.add(_norm(txt))
    return strip


def _merge_orphans(lines):
    """孤儿符号回挂: 与正文断行的列表符/序号回挂为 "- 正文" / "N. 正文"。

    连续符号行(布局幽灵,如页边距栏步骤号)互不回挂,直接丢弃——
    真实序号列表的序号与正文在同一文本对象内,不产生孤儿行。
    返回 (新行列表, 回挂数, 丢弃幽灵数)。
    """
    def is_marker(t):
        return bool(BULLET_ONLY_PAT.match(t) or NUM_ONLY_PAT.match(t))

    out = []
    merged = dropped = 0
    i = 0
    while i < len(lines):
        txt = lines[i]
        if is_marker(txt):
            if i + 1 < len(lines) and not is_marker(lines[i + 1]):
                if BULLET_ONLY_PAT.match(txt):
                    out.append("- " + lines[i + 1])
                else:
                    marker = NUM_ONLY_PAT.match(txt).group(1)
                    marker = marker if marker.endswith((".", "、")) else marker + "."
                    out.append(marker + " " + lines[i + 1])
                merged += 1
                i += 2
                continue
            dropped += 1  # 连续符号行(布局幽灵)或页尾孤儿 → 丢弃
            i += 1
            continue
        out.append(txt)
        i += 1
    return out, merged, dropped


def _apply_links(text, links):
    """链接内联/脚注降级。返回 (新文本, 内联数, 脚注列表)。

    内联启发式(按序尝试,命中即止):
      ① 矩形锚文本(上游给定且能在正文找到时);
      ② URL 尾段文件名回查正文——下载链接(evolve-setup-*.zip)的可见标签
         即文件名,内联为 [evolve-setup-claude_code.zip](url)。
    均未命中 → 页尾脚注(不丢 URL)。
    """
    inlined = 0
    footnotes = []
    seen = set()
    for anchor, url in links:
        if url in seen:
            continue
        seen.add(url)
        done = False
        for cand in (anchor, _url_tail(url)):
            if cand and 3 < len(cand) <= 120 and cand in text:
                text = text.replace(cand, f"[{cand}]({url})", 1)
                inlined += 1
                done = True
                break
        if not done:
            footnotes.append(url)
    if footnotes:
        text = text.rstrip() + "\n\n本页链接:\n" + "\n".join(f"- {u}" for u in footnotes)
    return text, inlined, footnotes


def _url_tail(url):
    """URL 尾段(去 query/fragment 后的文件名),无尾段返回空。"""
    tail = re.split(r"[?#]", url, 1)[0].rstrip("/")
    tail = tail.rsplit("/", 1)[-1]
    return tail if tail and "." in tail else ""


def main():
    _utf8_stdio()
    ap = argparse.ArgumentParser(description="PDF 文字层直提(pypdfium2,零 OCR,v0.6.3 结构增强)")
    ap.add_argument("pdf", help="输入 PDF 路径")
    ap.add_argument("--no-links", action="store_true", help="关闭链接提取")
    ap.add_argument("--no-headers", action="store_true", help="关闭页眉页脚剥离")
    ap.add_argument("--margin", type=float, default=MARGIN_RATIO, help="边距带比例(默认 0.12)")
    args = ap.parse_args()
    try:
        pdf = pdfium.PdfDocument(args.pdf)
    except Exception as e:
        print(json.dumps({"ok": False, "error": "PDF 打开失败: %s" % str(e)[:200]}, ensure_ascii=False))
        return 1

    notes = {"links_inlined": 0, "links_footnote": 0, "stripped_lines": 0, "orphan_merged": 0, "orphan_dropped": 0}
    pages_meta = []
    raw_pages = []  # [(no, page, tp, lines)]
    for i in range(len(pdf)):
        page = pdf[i]
        try:
            tp = page.get_textpage()
        except Exception:
            tp = None
        lines = _page_lines(tp) if tp is not None else None
        page_h = 0.0
        try:
            page_h = float(page.get_size()[1])
        except Exception:
            page_h = 0.0
        if lines is None:
            # 保底:行框 API 异常 → 旧版全文直提
            try:
                txt = tp.get_text_bounded() if tp is not None else ""
            except Exception:
                txt = ""
            lines = [(0.0, 0.0, ln.strip()) for ln in (txt or "").splitlines() if ln.strip()]
        raw_pages.append((i + 1, page, tp, lines))
        pages_meta.append({"no": i + 1, "lines": lines, "page_h": page_h})

    strip_set = set() if args.no_headers else _detect_headers_footers(pages_meta, args.margin)

    pages = []
    for no, page, tp, lines in raw_pages:
        kept = []
        for b, t, txt in lines:
            if _norm(txt) in strip_set:
                notes["stripped_lines"] += 1
                continue
            kept.append(txt)
        kept, merged, dropped = _merge_orphans(kept)
        notes["orphan_merged"] += merged
        notes["orphan_dropped"] += dropped
        text = "\n".join(kept)
        if not args.no_links and tp is not None:
            links = _page_links(pdf.raw, page.raw)
            if links:
                text, inlined, foot = _apply_links(text, links)
                notes["links_inlined"] += inlined
                notes["links_footnote"] += len(foot)
        pages.append({"no": no, "text": text})

    print(json.dumps({"total": len(pages), "pages": pages, "notes": notes}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
