# -*- coding: utf-8 -*-
"""
dsh-md-convert — PDF 文字层直提兜底(pypdfium2 get_text_bounded)

用途: markitdown-node 在宿主运行时(Electron 内置 Node)内对部分文字层 PDF
失败/返回空时的秒级兜底——纯文字提取,无版面结构(标题/表格不还原)。
依赖与 parallel_ocr.py 相同的 pypdfium2,零新增依赖。

stdout 协议(单个 JSON,UTF-8):
  {"total": 9, "pages": [{"no": 1, "text": "..."}, ...]}
  打不开 PDF: {"ok": false, "error": "..."} 并退出码 1
"""
import argparse
import json
import sys

import pypdfium2 as pdfium


def _utf8_stdio():
    """Windows 管道默认 GBK,JSON 输出强制 UTF-8。"""
    for s in (sys.stdout, sys.stderr):
        try:
            s.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


def main():
    _utf8_stdio()
    ap = argparse.ArgumentParser(description="PDF 文字层直提(pypdfium2,零 OCR)")
    ap.add_argument("pdf", help="输入 PDF 路径")
    args = ap.parse_args()
    try:
        pdf = pdfium.PdfDocument(args.pdf)
    except Exception as e:
        print(json.dumps({"ok": False, "error": "PDF 打开失败: %s" % str(e)[:200]}, ensure_ascii=False))
        return 1
    pages = []
    for i in range(len(pdf)):
        try:
            txt = pdf[i].get_textpage().get_text_bounded()
        except Exception:
            txt = ""
        pages.append({"no": i + 1, "text": txt or ""})
    print(json.dumps({"total": len(pages), "pages": pages}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
