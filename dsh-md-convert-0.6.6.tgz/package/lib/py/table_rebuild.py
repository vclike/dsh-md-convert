# -*- coding: utf-8 -*-
"""
dsh-md-convert — PDF 表格重建(v0.6.6 P1-A)

原理: 文字层 PDF 的表格由矢量线框(PATH 对象)+单元格文本构成——
  ① 线框检测: PATH 对象 bounds 按形态分类(横线/竖线/其他),坐标聚类成行/列边界;
  ② 网格判定: 横线≥2组 且 竖线≥2组 → 行x列网格(单元格数≥3 才算表格,排除装饰线);
  ③ 单元格文本: textpage.get_text_bounded(单元格矩形内缩 1pt) 直接取,行间空格合并;
  ④ md 输出: 首行=表头,次行 |---| 分隔;单元格内竖线转义。
降级: 无线框表格(纯对齐排版)检测不到网格 → 返回空列表,文本流保持原状(诚实降级)。
跨页表格 v1 不合并(每页独立检测)。
"""
import ctypes

import pypdfium2.raw as pdfium_c

try:
    import pypdfium2.raw as _pc
    pdfium_c = _pc
except Exception:  # pragma: no cover
    pdfium_c = None

PATH_TYPE = 2
# 线条形态阈值(pt):高度≤此值视为横线,宽度≤此值视为竖线
LINE_THICKNESS = 1.5
# 线段最短有效长度(pt),排除短装饰
LINE_MIN_LEN = 4.0
# 坐标聚类容差(pt)
CLUSTER_TOL = 2.0
# 表格资格:行列边界数(横线组/竖线组)最小值
MIN_ROW_LINES = 2
MIN_COL_LINES = 2
# 单元格内缩(pt),避免 get_text_bounded 串入相邻格字符
CELL_INSET = 1.0


def _cluster(vals, tol=CLUSTER_TOL):
    """坐标聚类(容差合并): [(代表值, 数量)],按代表值升序。"""
    if not vals:
        return []
    vals = sorted(vals)
    groups = [[vals[0]]]
    for v in vals[1:]:
        if v - groups[-1][-1] <= tol:
            groups[-1].append(v)
        else:
            groups.append([v])
    return [(round(sum(g) / len(g), 1), len(g)) for g in groups]


def detect_tables(page, tp):
    """检测页内线框表格。

    返回 [{"rect": (x0,y0,x1,y1), "rows": [y边界], "cols": [x边界]}, ...](按 y 降序);
    检测失败/无表格 → []。
    """
    if pdfium_c is None:
        return []
    try:
        hlines, vlines = [], []
        count = pdfium_c.FPDFPage_CountObjects(page.raw)
        for i in range(min(count, 4096)):
            obj = pdfium_c.FPDFPage_GetObject(page.raw, i)
            if not obj:
                continue
            if pdfium_c.FPDFPageObj_GetType(obj) != PATH_TYPE:
                continue
            l, b, r, t = ctypes.c_float(), ctypes.c_float(), ctypes.c_float(), ctypes.c_float()
            if not pdfium_c.FPDFPageObj_GetBounds(obj, ctypes.byref(l), ctypes.byref(b), ctypes.byref(r), ctypes.byref(t)):
                continue
            wd, ht = r.value - l.value, t.value - b.value
            if ht <= LINE_THICKNESS and wd > LINE_MIN_LEN:
                hlines.append(b.value)
            elif wd <= LINE_THICKNESS and ht > LINE_MIN_LEN:
                vlines.append(l.value)
        hc = _cluster(hlines)
        vc = _cluster(vlines)
        if len(hc) < MIN_ROW_LINES or len(vc) < MIN_COL_LINES:
            return []
        ys = [g[0] for g in hc]
        xs = [g[0] for g in vc]
        rect = (min(xs), min(ys), max(xs), max(ys))
        return [{"rect": rect, "rows": ys, "cols": xs}]
    except Exception:
        return []


def _cell_text(tp, cell):
    """单元格文本(内缩矩形取词,行合并为空格;竖线转义)。"""
    x0, y0, x1, y1 = cell
    try:
        txt = tp.get_text_bounded(left=x0 + CELL_INSET, bottom=y0 + CELL_INSET, right=x1 - CELL_INSET, top=y1 - CELL_INSET)
    except Exception:
        txt = ""
    lines = [ln.strip() for ln in (txt or "").splitlines() if ln.strip()]
    return " ".join(lines).replace("|", "\\|").strip()


def rebuild_table_md(tp, table):
    """网格 → markdown 表格文本。

    单元格 = 相邻行/列边界围成;行按 pdfium 坐标(y 向上)从表头到末行排序。
    全空表(区域内无任何文本)返回 ""(调用方丢弃,视为装饰线框)。
    """
    ys = table["rows"]
    xs = table["cols"]
    rows_md = []
    for ri in range(len(ys) - 1, 0, -1):  # y 向上:从最高边界对(表头)到最低
        cells = []
        for ci in range(len(xs) - 1):
            cell = (xs[ci], ys[ri - 1], xs[ci + 1], ys[ri])
            cells.append(_cell_text(tp, cell))
        rows_md.append(cells)
    if not any(any(c for c in row) for row in rows_md):
        return ""
    out = ["| " + " | ".join(rows_md[0]) + " |", "| " + " | ".join(["---"] * len(rows_md[0])) + " |"]
    for row in rows_md[1:]:
        out.append("| " + " | ".join(row) + " |")
    return "\n".join(out)


def rebuild_tables(page, tp):
    """检测+重建,返回 [(y_top, y_bottom, md_table)](y 降序);空串已剔除。"""
    tables = []
    for t in detect_tables(page, tp):
        md = rebuild_table_md(tp, t)
        if md:
            x0, y0, x1, y1 = t["rect"]
            tables.append((y1, y0, md))  # (top, bottom, md)
    tables.sort(key=lambda item: -item[0])
    return tables
